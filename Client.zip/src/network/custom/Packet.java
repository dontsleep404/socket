package network.custom;

public class Packet {

}
