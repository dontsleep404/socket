package network.custom.cpacket;

import network.custom.Packet;

public class CPacketJoin extends Packet{
	
}
